class Score:

    def __init__(self):
        self.myScore = 0
        pass

    def set_score_plus(self):
        self.myScore = self.myScore + 1
        
        pass

    def set_score_minus(self):
        self.myScore = self.myScore - 1
        
        pass 

    def get_score(self):
        return self.myScore